import 'package:flutter/material.dart';

class FavoriteView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Text("FavoriteView"),
      ),
    );
  }
}
